by sirmilkman(2025)
Licensed under Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
For more info: https://creativecommons.org/licenses/by-sa/4.0/

---

Training maps in Samurai Gunn 2
This pack replaces every cemetery stage. 

---

Visit https://www.sirmilkman.com/SG2Modding for instructions for an installation guide.

---

Important Note: 
Install which color theme you want and move the setdresses to their proper folder.
Color themes are NOT tied to setdresses, they are tied to the xdelta patches because they change the sprite files.

---

Info for each stage:

Crossing has been changed to use simpler geometry, but is still built around the bottom-screen wrap.
Depths is designed around vertical wrapping, but also has some ledges to hang out on.
Bedrock has been changed to a flat plane with horizontal screen wrap. 
Nostril has been changed to a flat plane with horizontal screen wrap with a few platforms.
Hollow has been changed to an enclosed box with a row of goo blocks.
Spider has been changed to a flat plane with a single platform in the center.
Boneyard has been changed to an empty enclosed box (Similar to empty jungle)
A friend was added to Lizard Tree (May rarely crash on load)

---

Thank you!