Samurai C-Sides Level Pack
V 0.1.5

This is a mod for Samurai Gunn 2
https://store.steampowered.com/app/1397790/Samurai_GUNN_2/

Created By:
sirmilkman 
waporwave

-----------------------------------

Levels Overwritten: 
Glade       -> Forest Temple 
Chasm       -> Stadium
Spines      -> Cliffside
Moat        -> Hotspring
Cell Block  -> Cell Ruins
Depths      -> Trail
Lizard Tree -> Forever
Thicket     -> Treetop

-----------------------------------

Update 0.1.5
-Fix broken collision on Stadium B 
-Fix broken collision on Trail A
-Change ambience on Trail A
