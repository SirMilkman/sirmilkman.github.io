Barbuta Entrance

This is a mod for Samurai Gunn 2
https://store.steampowered.com/app/1397790/Samurai_GUNN_2/

Created by sirmilkman 

Levels Overwritten: 
Cell Block (A and B)  -> Entrance
